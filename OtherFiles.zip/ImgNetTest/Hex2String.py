# 00037ed0ce93ed9826fafad2aef98890
import codecs

print(codecs.decode(codecs.decode('707974686f6e2d666f72756d2e696f','hex'),'ascii'))
print(codecs.decode("00037ed0ce93ed9826fafad2aef98890", "hex").decode('utf-8'))